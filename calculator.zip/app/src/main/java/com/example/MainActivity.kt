package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.calculator.BengaliConverter
import com.example.calculator.CalculationHistory
import com.example.calculator.CalculatorEngine
import com.example.calculator.CalculatorUiState
import com.example.calculator.CalculatorViewModel
import com.example.calculator.NumberScript
import com.example.ui.theme.CalculatorTheme
import com.example.ui.theme.SophisticatedBackground
import com.example.ui.theme.SophisticatedEqualsBg
import com.example.ui.theme.SophisticatedEqualsText
import com.example.ui.theme.SophisticatedFuncButtonBg
import com.example.ui.theme.SophisticatedFuncButtonText
import com.example.ui.theme.SophisticatedKeypadContainer
import com.example.ui.theme.SophisticatedNumberBg
import com.example.ui.theme.SophisticatedNumberText
import com.example.ui.theme.SophisticatedOnSurface
import com.example.ui.theme.SophisticatedOnSurfaceVariant
import com.example.ui.theme.SophisticatedOperatorBg
import com.example.ui.theme.SophisticatedOperatorText
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CalculatorTheme {
                CalculatorScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalculatorScreen(
    viewModel: CalculatorViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var showHistorySheet by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("calculator_root_screen"),
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Calculate,
                            contentDescription = null,
                            tint = SophisticatedEqualsBg,
                            modifier = Modifier.size(22.dp)
                        )
                        Text(
                            text = if (uiState.numberScript == NumberScript.BENGALI) "ক্যালকুলেটর" else "Calculator",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Medium,
                                fontSize = 20.sp,
                                letterSpacing = (-0.5).sp
                            ),
                            color = SophisticatedOnSurface
                        )
                    }
                },
                actions = {
                    // Script Switcher (BN / EN) with Sophisticated Dark circular styling
                    IconButton(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            viewModel.toggleNumberScript()
                        },
                        modifier = Modifier
                            .padding(end = 6.dp)
                            .size(40.dp)
                            .clip(CircleShape)
                            .testTag("btn_toggle_script"),
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = SophisticatedFuncButtonBg,
                            contentColor = SophisticatedOnSurface
                        )
                    ) {
                        Text(
                            text = if (uiState.numberScript == NumberScript.BENGALI) "১২৩" else "123",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            ),
                            color = SophisticatedOnSurface
                        )
                    }
                    // History Button with Sophisticated Dark circular styling
                    IconButton(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            showHistorySheet = true
                        },
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .size(40.dp)
                            .clip(CircleShape)
                            .testTag("btn_history"),
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = SophisticatedFuncButtonBg,
                            contentColor = SophisticatedOnSurface
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "Calculation History",
                            modifier = Modifier.size(20.dp),
                            tint = SophisticatedOnSurface
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = SophisticatedBackground
                )
            )
        },
        containerColor = SophisticatedBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Display Section
            DisplaySection(
                uiState = uiState,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 28.dp, vertical = 16.dp)
            )

            // Keypad Section wrapped in Sophisticated Dark rounded-t-32px container
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
                color = SophisticatedKeypadContainer
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding(),
                    contentAlignment = Alignment.Center
                ) {
                    KeypadSection(
                        uiState = uiState,
                        onDigitClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            viewModel.onDigitClick(it)
                        },
                        onDecimalClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            viewModel.onDecimalClick()
                        },
                        onOperatorClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            viewModel.onOperatorClick(it)
                        },
                        onEqualsClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            viewModel.onEqualsClick()
                        },
                        onClearClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            viewModel.onClearClick()
                        },
                        onBackspaceClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            viewModel.onBackspaceClick()
                        },
                        onPercentageClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            viewModel.onPercentageClick()
                        },
                        onToggleSignClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            viewModel.onToggleSignClick()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .widthIn(max = 480.dp)
                            .padding(horizontal = 20.dp, vertical = 24.dp)
                    )
                }
            }
        }
    }

    if (showHistorySheet) {
        ModalBottomSheet(
            onDismissRequest = { showHistorySheet = false },
            sheetState = sheetState,
            containerColor = SophisticatedKeypadContainer
        ) {
            HistorySheetContent(
                history = uiState.history,
                numberScript = uiState.numberScript,
                onSelectHistory = { item ->
                    viewModel.restoreHistoryItem(item)
                    scope.launch { sheetState.hide() }.invokeOnCompletion {
                        if (!sheetState.isVisible) showHistorySheet = false
                    }
                },
                onClearHistory = {
                    viewModel.clearHistory()
                }
            )
        }
    }
}

@Composable
fun DisplaySection(
    uiState: CalculatorUiState,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    LaunchedEffect(uiState.expression) {
        scrollState.animateScrollTo(scrollState.maxValue)
    }

    val displayExpr = remember(uiState.expression, uiState.numberScript) {
        if (uiState.numberScript == NumberScript.BENGALI) {
            BengaliConverter.toBengali(uiState.expression)
        } else {
            uiState.expression
        }
    }

    val displayPreview = remember(uiState.previewResult, uiState.numberScript) {
        if (uiState.previewResult.isNotEmpty()) {
            val formatted = if (uiState.numberScript == NumberScript.BENGALI) {
                BengaliConverter.toBengali(uiState.previewResult)
            } else {
                uiState.previewResult
            }
            "= $formatted"
        } else {
            ""
        }
    }

    Column(
        modifier = modifier.testTag("display_card"),
        verticalArrangement = Arrangement.Bottom,
        horizontalAlignment = Alignment.End
    ) {
        // Error Indicator
        AnimatedVisibility(
            visible = uiState.errorMessage != null,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Text(
                text = uiState.errorMessage ?: "",
                style = MaterialTheme.typography.titleMedium.copy(
                    color = MaterialTheme.colorScheme.error,
                    fontWeight = FontWeight.SemiBold
                ),
                modifier = Modifier
                    .padding(bottom = 8.dp)
                    .testTag("error_message")
            )
        }

        // Previous Expression / Live Preview (Sophisticated Dark Opacity 60%)
        if (displayPreview.isNotEmpty()) {
            Text(
                text = displayPreview,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Light,
                    letterSpacing = 0.5.sp
                ),
                color = SophisticatedOnSurfaceVariant.copy(alpha = 0.7f),
                textAlign = TextAlign.End,
                modifier = Modifier
                    .padding(bottom = 6.dp)
                    .testTag("display_preview")
            )
        } else {
            Text(
                text = " ",
                style = MaterialTheme.typography.titleMedium.copy(fontSize = 18.sp),
                modifier = Modifier.padding(bottom = 6.dp)
            )
        }

        // Main Expression / Result (6xl display typography)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(scrollState),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val fontSize = when {
                displayExpr.length > 18 -> 32.sp
                displayExpr.length > 12 -> 40.sp
                displayExpr.length > 8 -> 48.sp
                else -> 56.sp
            }

            Text(
                text = displayExpr,
                style = MaterialTheme.typography.displayLarge.copy(
                    fontSize = fontSize,
                    fontWeight = FontWeight.Normal,
                    textAlign = TextAlign.End,
                    letterSpacing = (-0.5).sp
                ),
                color = SophisticatedOnSurface,
                maxLines = 1,
                modifier = Modifier.testTag("display_expression")
            )
        }
    }
}

@Composable
fun KeypadSection(
    uiState: CalculatorUiState,
    onDigitClick: (String) -> Unit,
    onDecimalClick: () -> Unit,
    onOperatorClick: (String) -> Unit,
    onEqualsClick: () -> Unit,
    onClearClick: () -> Unit,
    onBackspaceClick: () -> Unit,
    onPercentageClick: () -> Unit,
    onToggleSignClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isBn = uiState.numberScript == NumberScript.BENGALI

    val digitLabel = { enDigit: String ->
        if (isBn) BengaliConverter.toBengali(enDigit) else enDigit
    }

    Column(
        modifier = modifier.testTag("keypad_grid"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Row 1: AC, +/-, %, ÷
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SophisticatedButton(
                text = "AC",
                type = ButtonType.FUNCTION,
                testTag = "btn_clear",
                modifier = Modifier.weight(1f),
                onClick = onClearClick
            )
            SophisticatedButton(
                text = "+/-",
                type = ButtonType.FUNCTION,
                testTag = "btn_sign",
                modifier = Modifier.weight(1f),
                onClick = onToggleSignClick
            )
            SophisticatedButton(
                text = "%",
                type = ButtonType.FUNCTION,
                testTag = "btn_percent",
                modifier = Modifier.weight(1f),
                onClick = onPercentageClick
            )
            SophisticatedButton(
                text = CalculatorEngine.OP_DIV,
                type = ButtonType.OPERATOR,
                testTag = "btn_divide",
                modifier = Modifier.weight(1f),
                onClick = { onOperatorClick(CalculatorEngine.OP_DIV) }
            )
        }

        // Row 2: 7, 8, 9, ×
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SophisticatedButton(
                text = digitLabel("7"),
                type = ButtonType.NUMBER,
                testTag = "btn_7",
                modifier = Modifier.weight(1f),
                onClick = { onDigitClick("7") }
            )
            SophisticatedButton(
                text = digitLabel("8"),
                type = ButtonType.NUMBER,
                testTag = "btn_8",
                modifier = Modifier.weight(1f),
                onClick = { onDigitClick("8") }
            )
            SophisticatedButton(
                text = digitLabel("9"),
                type = ButtonType.NUMBER,
                testTag = "btn_9",
                modifier = Modifier.weight(1f),
                onClick = { onDigitClick("9") }
            )
            SophisticatedButton(
                text = CalculatorEngine.OP_MUL,
                type = ButtonType.OPERATOR,
                testTag = "btn_multiply",
                modifier = Modifier.weight(1f),
                onClick = { onOperatorClick(CalculatorEngine.OP_MUL) }
            )
        }

        // Row 3: 4, 5, 6, −
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SophisticatedButton(
                text = digitLabel("4"),
                type = ButtonType.NUMBER,
                testTag = "btn_4",
                modifier = Modifier.weight(1f),
                onClick = { onDigitClick("4") }
            )
            SophisticatedButton(
                text = digitLabel("5"),
                type = ButtonType.NUMBER,
                testTag = "btn_5",
                modifier = Modifier.weight(1f),
                onClick = { onDigitClick("5") }
            )
            SophisticatedButton(
                text = digitLabel("6"),
                type = ButtonType.NUMBER,
                testTag = "btn_6",
                modifier = Modifier.weight(1f),
                onClick = { onDigitClick("6") }
            )
            SophisticatedButton(
                text = CalculatorEngine.OP_SUB,
                type = ButtonType.OPERATOR,
                testTag = "btn_subtract",
                modifier = Modifier.weight(1f),
                onClick = { onOperatorClick(CalculatorEngine.OP_SUB) }
            )
        }

        // Row 4: 1, 2, 3, +
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SophisticatedButton(
                text = digitLabel("1"),
                type = ButtonType.NUMBER,
                testTag = "btn_1",
                modifier = Modifier.weight(1f),
                onClick = { onDigitClick("1") }
            )
            SophisticatedButton(
                text = digitLabel("2"),
                type = ButtonType.NUMBER,
                testTag = "btn_2",
                modifier = Modifier.weight(1f),
                onClick = { onDigitClick("2") }
            )
            SophisticatedButton(
                text = digitLabel("3"),
                type = ButtonType.NUMBER,
                testTag = "btn_3",
                modifier = Modifier.weight(1f),
                onClick = { onDigitClick("3") }
            )
            SophisticatedButton(
                text = CalculatorEngine.OP_ADD,
                type = ButtonType.OPERATOR,
                testTag = "btn_add",
                modifier = Modifier.weight(1f),
                onClick = { onOperatorClick(CalculatorEngine.OP_ADD) }
            )
        }

        // Row 5: 0, ., ⌫, =
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SophisticatedButton(
                text = digitLabel("0"),
                type = ButtonType.NUMBER,
                testTag = "btn_0",
                modifier = Modifier.weight(1f),
                onClick = { onDigitClick("0") }
            )
            SophisticatedButton(
                text = ".",
                type = ButtonType.NUMBER,
                testTag = "btn_decimal",
                modifier = Modifier.weight(1f),
                onClick = onDecimalClick
            )
            SophisticatedIconButton(
                icon = Icons.Default.Backspace,
                contentDescription = "Backspace",
                type = ButtonType.NUMBER,
                testTag = "btn_backspace",
                modifier = Modifier.weight(1f),
                onClick = onBackspaceClick
            )
            SophisticatedButton(
                text = "=",
                type = ButtonType.EQUALS,
                testTag = "btn_equals",
                modifier = Modifier.weight(1f),
                onClick = onEqualsClick
            )
        }
    }
}

enum class ButtonType {
    NUMBER,
    OPERATOR,
    FUNCTION,
    EQUALS
}

@Composable
fun SophisticatedButton(
    text: String,
    type: ButtonType,
    testTag: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val (containerColor, contentColor, fontSize, fontWeight) = when (type) {
        ButtonType.FUNCTION -> Quadruple(
            SophisticatedFuncButtonBg,
            SophisticatedFuncButtonText,
            20.sp,
            FontWeight.Medium
        )
        ButtonType.OPERATOR -> Quadruple(
            SophisticatedOperatorBg,
            SophisticatedOperatorText,
            24.sp,
            FontWeight.Medium
        )
        ButtonType.NUMBER -> Quadruple(
            SophisticatedNumberBg,
            SophisticatedNumberText,
            24.sp,
            FontWeight.Normal
        )
        ButtonType.EQUALS -> Quadruple(
            SophisticatedEqualsBg,
            SophisticatedEqualsText,
            26.sp,
            FontWeight.Bold
        )
    }

    Button(
        onClick = onClick,
        modifier = modifier
            .aspectRatio(1.15f)
            .testTag(testTag),
        shape = CircleShape,
        colors = ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = contentColor
        ),
        contentPadding = PaddingValues(0.dp),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.titleLarge.copy(
                fontSize = fontSize,
                fontWeight = fontWeight
            )
        )
    }
}

@Composable
fun SophisticatedIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    type: ButtonType,
    testTag: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val (containerColor, contentColor) = when (type) {
        ButtonType.FUNCTION -> SophisticatedFuncButtonBg to SophisticatedFuncButtonText
        ButtonType.OPERATOR -> SophisticatedOperatorBg to SophisticatedOperatorText
        ButtonType.NUMBER -> SophisticatedNumberBg to SophisticatedNumberText
        ButtonType.EQUALS -> SophisticatedEqualsBg to SophisticatedEqualsText
    }

    Button(
        onClick = onClick,
        modifier = modifier
            .aspectRatio(1.15f)
            .testTag(testTag),
        shape = CircleShape,
        colors = ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = contentColor
        ),
        contentPadding = PaddingValues(0.dp),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            modifier = Modifier.size(22.dp)
        )
    }
}

data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

@Composable
fun HistorySheetContent(
    history: List<CalculationHistory>,
    numberScript: NumberScript,
    onSelectHistory: (CalculationHistory) -> Unit,
    onClearHistory: () -> Unit
) {
    val isBn = numberScript == NumberScript.BENGALI

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 16.dp)
            .testTag("history_sheet")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isBn) "হিসাবের ইতিহাস" else "Calculation History",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = SophisticatedOnSurface
                )
            )
            if (history.isNotEmpty()) {
                IconButton(
                    onClick = onClearHistory,
                    modifier = Modifier.testTag("btn_clear_history")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteSweep,
                        contentDescription = "Clear History",
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }
        }

        HorizontalDivider(
            modifier = Modifier.padding(vertical = 12.dp),
            color = SophisticatedFuncButtonBg
        )

        if (history.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 40.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isBn) "কোন পূর্ববর্তী হিসাব নেই" else "No recent calculations",
                    style = MaterialTheme.typography.bodyLarge,
                    color = SophisticatedOnSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(320.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(history, key = { it.id }) { item ->
                    val expr = if (isBn) BengaliConverter.toBengali(item.expression) else item.expression
                    val res = if (isBn) BengaliConverter.toBengali(item.result) else item.result

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectHistory(item) }
                            .testTag("history_item_${item.id}"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = SophisticatedNumberBg
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.End
                        ) {
                            Text(
                                text = expr,
                                style = MaterialTheme.typography.bodyMedium,
                                color = SophisticatedOnSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "= $res",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold
                                ),
                                color = SophisticatedEqualsBg
                            )
                        }
                    }
                }
            }
        }
    }
}
