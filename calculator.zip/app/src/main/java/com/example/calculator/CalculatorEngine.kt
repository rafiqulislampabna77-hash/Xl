package com.example.calculator

import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

data class CalculationHistory(
    val id: Long = System.currentTimeMillis(),
    val expression: String,
    val result: String,
    val timestamp: Long = System.currentTimeMillis()
)

enum class NumberScript {
    ENGLISH,
    BENGALI
}

object BengaliConverter {
    private val enToBnDigits = mapOf(
        '0' to '০',
        '1' to '১',
        '2' to '২',
        '3' to '৩',
        '4' to '৪',
        '5' to '৫',
        '6' to '৬',
        '7' to '৭',
        '8' to '৮',
        '9' to '৯',
        '.' to '.'
    )

    private val bnToEnDigits = enToBnDigits.entries.associate { (k, v) -> v to k }

    fun toBengali(text: String): String {
        return text.map { enToBnDigits[it] ?: it }.joinToString("")
    }

    fun toEnglish(text: String): String {
        return text.map { bnToEnDigits[it] ?: it }.joinToString("")
    }
}

class CalculatorEngine {

    companion object {
        const val OP_ADD = "+"
        const val OP_SUB = "−"
        const val OP_MUL = "×"
        const val OP_DIV = "÷"
    }

    /**
     * Evaluates a mathematical expression string containing numbers and operators (+, −, ×, ÷, %).
     * Returns the formatted result or null if invalid/incomplete.
     */
    fun evaluate(expression: String): Result<String> {
        if (expression.isBlank()) return Result.failure(IllegalArgumentException("Empty expression"))

        try {
            val normalized = normalizeExpression(expression)
            val tokens = tokenize(normalized)
            if (tokens.isEmpty()) return Result.failure(IllegalArgumentException("No valid tokens"))

            val result = evaluateTokens(tokens)
            return Result.success(formatResult(result))
        } catch (e: ArithmeticException) {
            return Result.failure(e)
        } catch (e: Exception) {
            return Result.failure(e)
        }
    }

    private fun normalizeExpression(expr: String): String {
        return expr
            .replace("−", "-")
            .replace("-", "-")
            .replace("×", "*")
            .replace("*", "*")
            .replace("÷", "/")
            .replace("/", "/")
            .replace(" ", "")
    }

    private fun tokenize(expr: String): List<String> {
        val tokens = mutableListOf<String>()
        var i = 0
        val len = expr.length

        while (i < len) {
            val c = expr[i]

            // Check if '-' is a unary minus for a negative number
            val isUnaryMinus = c == '-' && (i == 0 || expr[i - 1] in "+-*/(")

            if (c.isDigit() || c == '.' || isUnaryMinus) {
                val sb = StringBuilder()
                if (isUnaryMinus) {
                    sb.append('-')
                    i++
                }
                while (i < len && (expr[i].isDigit() || expr[i] == '.')) {
                    sb.append(expr[i])
                    i++
                }
                // Check if followed by %
                if (i < len && expr[i] == '%') {
                    val numStr = sb.toString()
                    val num = BigDecimal(numStr).divide(BigDecimal("100"), MathContext.DECIMAL128)
                    tokens.add(num.toPlainString())
                    i++
                } else {
                    tokens.add(sb.toString())
                }
            } else if (c in "+-*/") {
                tokens.add(c.toString())
                i++
            } else if (c == '%') {
                // If % is isolated after token
                if (tokens.isNotEmpty() && tokens.last().toDoubleOrNull() != null) {
                    val last = BigDecimal(tokens.removeAt(tokens.size - 1))
                    val pct = last.divide(BigDecimal("100"), MathContext.DECIMAL128)
                    tokens.add(pct.toPlainString())
                }
                i++
            } else {
                i++
            }
        }
        return tokens
    }

    private fun evaluateTokens(tokens: List<String>): BigDecimal {
        if (tokens.isEmpty()) throw IllegalArgumentException("No tokens to evaluate")

        // First pass: Handle Multiplication (*) and Division (/)
        val intermediateTokens = mutableListOf<String>()
        var i = 0
        while (i < tokens.size) {
            val token = tokens[i]
            if (token == "*" || token == "/") {
                if (intermediateTokens.isEmpty() || i + 1 >= tokens.size) {
                    throw IllegalArgumentException("Invalid syntax around operator $token")
                }
                val prev = BigDecimal(intermediateTokens.removeAt(intermediateTokens.size - 1))
                val next = BigDecimal(tokens[i + 1])
                val result = if (token == "*") {
                    prev.multiply(next, MathContext.DECIMAL128)
                } else {
                    if (next.compareTo(BigDecimal.ZERO) == 0) {
                        throw ArithmeticException("Cannot divide by zero")
                    }
                    prev.divide(next, 12, RoundingMode.HALF_UP)
                }
                intermediateTokens.add(result.stripTrailingZeros().toPlainString())
                i += 2
            } else {
                intermediateTokens.add(token)
                i++
            }
        }

        // Second pass: Handle Addition (+) and Subtraction (-)
        if (intermediateTokens.isEmpty()) throw IllegalArgumentException("No valid tokens in second pass")
        var current = BigDecimal(intermediateTokens[0])
        var j = 1
        while (j < intermediateTokens.size) {
            val op = intermediateTokens[j]
            if (j + 1 >= intermediateTokens.size) {
                throw IllegalArgumentException("Incomplete expression")
            }
            val next = BigDecimal(intermediateTokens[j + 1])
            current = when (op) {
                "+" -> current.add(next, MathContext.DECIMAL128)
                "-" -> current.subtract(next, MathContext.DECIMAL128)
                else -> throw IllegalArgumentException("Unexpected operator: $op")
            }
            j += 2
        }

        return current
    }

    private fun formatResult(value: BigDecimal): String {
        val stripped = value.stripTrailingZeros()
        // If absolute value is extremely large or very tiny decimal, format cleanly
        val absVal = stripped.abs()
        return if (absVal >= BigDecimal("1000000000000") || (absVal > BigDecimal.ZERO && absVal < BigDecimal("0.000001"))) {
            val df = DecimalFormat("0.######E0", DecimalFormatSymbols(Locale.US))
            df.format(stripped)
        } else {
            // Standard plain string without exponent
            stripped.toPlainString()
        }
    }
}
