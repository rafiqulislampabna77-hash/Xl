package com.example.calculator

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class CalculatorUiState(
    val expression: String = "0",
    val previewResult: String = "",
    val isEvaluated: Boolean = false,
    val errorMessage: String? = null,
    val history: List<CalculationHistory> = emptyList(),
    val numberScript: NumberScript = NumberScript.ENGLISH
)

class CalculatorViewModel(
    private val engine: CalculatorEngine = CalculatorEngine()
) : ViewModel() {

    private val _uiState = MutableStateFlow(CalculatorUiState())
    val uiState: StateFlow<CalculatorUiState> = _uiState.asStateFlow()

    fun onDigitClick(digit: String) {
        _uiState.update { state ->
            val currentExpr = if (state.isEvaluated || state.expression == "0" || state.errorMessage != null) {
                digit
            } else {
                state.expression + digit
            }
            val preview = calculatePreview(currentExpr)
            state.copy(
                expression = currentExpr,
                previewResult = preview,
                isEvaluated = false,
                errorMessage = null
            )
        }
    }

    fun onDecimalClick() {
        _uiState.update { state ->
            val expr = if (state.isEvaluated || state.errorMessage != null) "0" else state.expression
            val lastSegment = expr.split(Regex("[+\\−×÷-]")).lastOrNull() ?: ""
            if (!lastSegment.contains(".")) {
                val newExpr = "$expr."
                state.copy(
                    expression = newExpr,
                    previewResult = calculatePreview(newExpr),
                    isEvaluated = false,
                    errorMessage = null
                )
            } else {
                state
            }
        }
    }

    fun onOperatorClick(operator: String) {
        _uiState.update { state ->
            if (state.errorMessage != null) {
                state.copy(
                    expression = "0 $operator ",
                    previewResult = "",
                    isEvaluated = false,
                    errorMessage = null
                )
            } else {
                val trimmed = state.expression.trimEnd()
                val newExpr = when {
                    trimmed.endsWith("+") || trimmed.endsWith("−") || trimmed.endsWith("×") || trimmed.endsWith("÷") -> {
                        trimmed.dropLast(1).trimEnd() + " $operator "
                    }
                    else -> "$trimmed $operator "
                }
                state.copy(
                    expression = newExpr,
                    previewResult = calculatePreview(newExpr),
                    isEvaluated = false,
                    errorMessage = null
                )
            }
        }
    }

    fun onEqualsClick() {
        val state = _uiState.value
        val expr = state.expression.trim()
        if (expr.isEmpty() || state.isEvaluated) return

        val result = engine.evaluate(expr)
        result.onSuccess { calculatedValue ->
            val historyItem = CalculationHistory(
                expression = expr,
                result = calculatedValue
            )
            _uiState.update {
                it.copy(
                    expression = calculatedValue,
                    previewResult = "",
                    isEvaluated = true,
                    errorMessage = null,
                    history = listOf(historyItem) + it.history.take(49)
                )
            }
        }.onFailure { error ->
            val errorMsg = if (error is ArithmeticException) {
                "Cannot divide by zero"
            } else {
                "Error"
            }
            _uiState.update {
                it.copy(
                    errorMessage = errorMsg,
                    previewResult = ""
                )
            }
        }
    }

    fun onClearClick() {
        _uiState.update {
            it.copy(
                expression = "0",
                previewResult = "",
                isEvaluated = false,
                errorMessage = null
            )
        }
    }

    fun onBackspaceClick() {
        _uiState.update { state ->
            if (state.errorMessage != null || state.isEvaluated) {
                state.copy(expression = "0", previewResult = "", isEvaluated = false, errorMessage = null)
            } else {
                val trimmed = state.expression.trimEnd()
                val newExpr = if (trimmed.length <= 1) {
                    "0"
                } else if (trimmed.endsWith(" +") || trimmed.endsWith(" −") || trimmed.endsWith(" ×") || trimmed.endsWith(" ÷")) {
                    trimmed.dropLast(2).trimEnd()
                } else {
                    trimmed.dropLast(1)
                }
                val finalExpr = if (newExpr.isEmpty()) "0" else newExpr
                state.copy(
                    expression = finalExpr,
                    previewResult = calculatePreview(finalExpr),
                    isEvaluated = false,
                    errorMessage = null
                )
            }
        }
    }

    fun onPercentageClick() {
        _uiState.update { state ->
            if (state.errorMessage != null) return@update state
            val trimmed = state.expression.trimEnd()
            if (trimmed.isEmpty() || trimmed.endsWith("+") || trimmed.endsWith("−") || trimmed.endsWith("×") || trimmed.endsWith("÷")) {
                return@update state
            }
            val newExpr = "$trimmed%"
            val res = engine.evaluate(newExpr)
            if (res.isSuccess) {
                val calculated = res.getOrThrow()
                state.copy(
                    expression = calculated,
                    previewResult = "",
                    isEvaluated = true,
                    errorMessage = null
                )
            } else {
                state
            }
        }
    }

    fun onToggleSignClick() {
        _uiState.update { state ->
            if (state.errorMessage != null) return@update state
            val expr = state.expression.trim()
            if (expr == "0") return@update state

            // Try to toggle sign on current expression or last number
            val result = engine.evaluate(expr)
            if (result.isSuccess) {
                val value = result.getOrThrow()
                val toggled = if (value.startsWith("-")) value.drop(1) else "-$value"
                state.copy(
                    expression = toggled,
                    previewResult = calculatePreview(toggled),
                    isEvaluated = true,
                    errorMessage = null
                )
            } else {
                state
            }
        }
    }

    fun toggleNumberScript() {
        _uiState.update { state ->
            val nextScript = if (state.numberScript == NumberScript.ENGLISH) {
                NumberScript.BENGALI
            } else {
                NumberScript.ENGLISH
            }
            state.copy(numberScript = nextScript)
        }
    }

    fun restoreHistoryItem(item: CalculationHistory) {
        _uiState.update {
            it.copy(
                expression = item.result,
                previewResult = "",
                isEvaluated = true,
                errorMessage = null
            )
        }
    }

    fun clearHistory() {
        _uiState.update {
            it.copy(history = emptyList())
        }
    }

    private fun calculatePreview(expr: String): String {
        val trimmed = expr.trimEnd()
        if (trimmed.isEmpty() || trimmed == "0") return ""
        if (trimmed.endsWith("+") || trimmed.endsWith("−") || trimmed.endsWith("×") || trimmed.endsWith("÷")) return ""

        // If there's an operator in the expression, evaluate preview
        if (trimmed.contains("+") || trimmed.contains("−") || trimmed.contains("×") || trimmed.contains("÷") || trimmed.contains("%")) {
            val res = engine.evaluate(trimmed)
            return res.getOrNull() ?: ""
        }
        return ""
    }
}
