package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sophisticated Dark Theme Colors
val SophisticatedBackground = Color(0xFF1C1B1F)
val SophisticatedSurface = Color(0xFF1C1B1F)
val SophisticatedOnSurface = Color(0xFFE6E1E5)
val SophisticatedOnSurfaceVariant = Color(0xFFCAC4D0)

// Keypad container surface
val SophisticatedKeypadContainer = Color(0xFF25232A)

// Button Tones
val SophisticatedFuncButtonBg = Color(0xFF49454F)
val SophisticatedFuncButtonText = Color(0xFFE6E1E5)

val SophisticatedOperatorBg = Color(0xFF4F378B)
val SophisticatedOperatorText = Color(0xFFEADDFF)

val SophisticatedNumberBg = Color(0xFF1C1B1F)
val SophisticatedNumberText = Color(0xFFE6E1E5)

val SophisticatedEqualsBg = Color(0xFFD0BCFF)
val SophisticatedEqualsText = Color(0xFF381E72)

// Subtle accents & Error
val SophisticatedError = Color(0xFFF2B8B5)
val SophisticatedOnError = Color(0xFF601410)
val SophisticatedErrorContainer = Color(0xFF8C1D18)
