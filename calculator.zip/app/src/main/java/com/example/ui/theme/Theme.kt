package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val SophisticatedDarkColorScheme = darkColorScheme(
    primary = SophisticatedEqualsBg,
    onPrimary = SophisticatedEqualsText,
    primaryContainer = SophisticatedOperatorBg,
    onPrimaryContainer = SophisticatedOperatorText,
    secondary = SophisticatedFuncButtonBg,
    onSecondary = SophisticatedFuncButtonText,
    secondaryContainer = SophisticatedFuncButtonBg,
    onSecondaryContainer = SophisticatedFuncButtonText,
    tertiary = SophisticatedOperatorBg,
    onTertiary = SophisticatedOperatorText,
    background = SophisticatedBackground,
    onBackground = SophisticatedOnSurface,
    surface = SophisticatedSurface,
    onSurface = SophisticatedOnSurface,
    surfaceVariant = SophisticatedKeypadContainer,
    onSurfaceVariant = SophisticatedOnSurfaceVariant,
    surfaceContainer = SophisticatedKeypadContainer,
    surfaceContainerHigh = SophisticatedFuncButtonBg,
    surfaceContainerHighest = SophisticatedOperatorBg,
    error = SophisticatedError,
    onError = SophisticatedOnError,
    errorContainer = SophisticatedErrorContainer
)

@Composable
fun CalculatorTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = SophisticatedDarkColorScheme,
        typography = Typography,
        content = content
    )
}
