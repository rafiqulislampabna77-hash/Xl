package com.example

import com.example.calculator.BengaliConverter
import com.example.calculator.CalculatorEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class ExampleUnitTest {

    private lateinit var engine: CalculatorEngine

    @Before
    fun setUp() {
        engine = CalculatorEngine()
    }

    @Test
    fun addition_isCorrect() {
        val result = engine.evaluate("15 + 27")
        assertTrue(result.isSuccess)
        assertEquals("42", result.getOrNull())
    }

    @Test
    fun subtraction_isCorrect() {
        val result = engine.evaluate("100 − 37")
        assertTrue(result.isSuccess)
        assertEquals("63", result.getOrNull())
    }

    @Test
    fun multiplication_isCorrect() {
        val result = engine.evaluate("12 × 8")
        assertTrue(result.isSuccess)
        assertEquals("96", result.getOrNull())
    }

    @Test
    fun division_isCorrect() {
        val result = engine.evaluate("144 ÷ 12")
        assertTrue(result.isSuccess)
        assertEquals("12", result.getOrNull())
    }

    @Test
    fun decimal_and_precedence_isCorrect() {
        val result = engine.evaluate("10 + 5 × 2 - 4 ÷ 2")
        assertTrue(result.isSuccess)
        assertEquals("18", result.getOrNull())
    }

    @Test
    fun divide_by_zero_throwsException() {
        val result = engine.evaluate("25 ÷ 0")
        assertTrue(result.isFailure)
    }

    @Test
    fun bengaliConverter_isCorrect() {
        val bn = BengaliConverter.toBengali("12345.67890")
        assertEquals("১২৩৪৫.৬৭৮৯০", bn)
        val en = BengaliConverter.toEnglish(bn)
        assertEquals("12345.67890", en)
    }
}
